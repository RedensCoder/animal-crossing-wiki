<template>
  <div class="wrapper">
    <Header/>
    <Search />
    <h3>Villagers</h3>
    <div class="wrapper__filter">
      <button @click="gender = ''" class="filter__button">All Gender</button>
      <button @click="gender = 'Male'" class="filter__button">Male</button>
      <button @click="gender = 'Female'" class="filter__button">Female</button>
    </div>
    <div class="wrapper__fishs">
      <div class="wrapper__fish" v-for="fish in Villagers.villagers" :key="fish.id">
        <img v-if="fish.gender === gender" :src=fish.icon_uri alt="fish" />
        <p v-if="fish.gender === gender" class="fish__name">{{fish.name["name-EUru"]}}</p>
        <p v-if="fish.gender === gender" class="fish__gender">{{fish.gender}}</p>
        <img v-if="gender === ''" :src=fish.icon_uri alt="fish" />
        <p v-if="gender === ''" class="fish__name">{{fish.name["name-EUru"]}}</p>
        <p v-if="gender === ''" class="fish__gender">{{fish.gender}}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import {useAllFetchStore} from "@/stores/AllFetch";
import {onMounted, ref} from "vue";

import Header from "./Header.vue";
import Search from "@/components/Search.vue";

const Villagers = useAllFetchStore();

const gender = ref("");

onMounted(() => {
  Villagers.Villagers();
})
</script>

<style lang="sass" scoped>
.wrapper
  text-align: center
  font-family: sans-serif
  h3
    font-size: 30px
    color: cornflowerblue

.wrapper__fish
  font-size: 20px
  margin-bottom: 50px
  .fish__name
    font-weight: 700

.wrapper__fishs
  display: grid
  grid-template-columns: 1fr 1fr 1fr 1fr
  margin-top: 25px

.filter__button
  margin-top: 15px
  background: cornflowerblue
  color: white
  padding: 10px 45px
  margin-left: 20px
  cursor: pointer
</style>