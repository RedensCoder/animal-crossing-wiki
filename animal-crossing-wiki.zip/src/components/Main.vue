<template>
  <Header/>
  <div class="wrapper">

  </div>
</template>

<script setup>
import Header from "./Header.vue";
</script>

<style lang="sass" scoped>

</style>